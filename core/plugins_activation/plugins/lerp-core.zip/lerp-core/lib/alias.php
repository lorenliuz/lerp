<?php

if ( !function_exists('lerp_sidebar_al') ) :
function lerp_sidebar_al( $type, $atts, $args ){
	the_widget( $type, $atts, $args );
}
endif;
